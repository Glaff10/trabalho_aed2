#include<'vetor.h'>

int main(){

	double media_bin=0, media_seq=0;
	int V;

	criar(V);

	for(int i=0; i<30; i++){

		double x;
		r = rand() % 20;
		x = busca_binaria(V, r, 0, 1000000);
		media_bin += x;
		printf("%lf\n", x);
		x = busca_sequencial(V, r, 0, 1000000);
		media_seq += x;
		printf("%lf\n", x);
	}

	printf("A media do tempo de execução na busca binaria == %lf\nA media do tempo de execução na busca sequencial == %lf\n", media_bin, media_seq);

	return 0;
}
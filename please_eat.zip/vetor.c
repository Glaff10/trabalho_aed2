#include<stdio.h>
#include<time.h>
#include<stdlib.h>

srand(time(NULL));
clock_t start, end;
double cpu_time_used;

int *criar(int v[]){

	v[0] = 1;
	for(int i=1; i<1000000; i++){

		v[i]=rand() % ((v[i-1] +5) + 1 - (v[i-1]+1)) + v[i-1]+1;
	}

	return v;
}

double busca_binaria(int v[], int chave, int ini, int fim){

	start = clock();

	int meio = (fim-ini)/2;

	while(chave!=meio){

		if(chave>v[meio])
		{
			ini = v[meio]+1;
			continue;
		}
		if(chave<v[meio])
		{
			fim = v[meio]-1;
			continue;
		}

	}

	end = clock();

	cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;

	return cpu_time_used;

}

double busca_sequencial(int v[], int chave){

	start = clock();

	for(int i=0; i<1000000; i++){
		if(v[i]==chave)break;
	}

	end = clock();

	cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;

	return 0;
}



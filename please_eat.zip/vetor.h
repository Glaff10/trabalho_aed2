#include<stdio.h>
#include<time.h>
#include<stdlib.h>

#ifndef VETOR_H_
#define VETOR_H_

int * cria(void);

double busca_binaria(int v[], int chave, int ini, int fim);

double busca_sequencial(int v[], int chave);
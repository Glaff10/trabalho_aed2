#include "vetor.h"

clock_t start, end;
double cpu_time_used;

int main(){

	double media_vetor=0, media_lista=0;
	int *V;
	tipoLista L;

    V = (int*) malloc(sizeof(int)*1000000);
    criarListaEncadeada(&L);

    preencheListaVetor (1000000, &L, V);

    int i=0;
	for( i=0; i<30; i++){

		int x;
		int r = rand() % 20;

		start = clock();

		x = BuscaSequencialVetor(r, 1000000, V);

		end = clock();

		cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;

		media_vetor += cpu_time_used;

		printf("O tempo de execução da %d busca, procurando o elemento %d em busca sequencial no vetor foi: %lf\n", i, x, cpu_time_used);

		start = clock();

		x = BuscaSequencialListaEncadeada(r, L);

		end = clock();

		cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;

		media_lista += cpu_time_used;

		printf("O tempo de execução da %d busca, procurando o elemento %d em busca sequencial na lista foi: %lf\n", i, x, cpu_time_used);
	}

	printf("A media do tempo de execução na busca sequencial no vetor == %lf\nA media do tempo de execução na busca sequencial na lista == %lf\n", media_vetor/30, media_lista/30);

	return 0;
}
